#!/usr/bin/env python
# coding: utf-8
import json
import time
import numpy as np
from tqdm import tqdm
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.svm import SVR
from sklearn.linear_model import LinearRegression, BayesianRidge, ElasticNet, Lasso, Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
import pandas as pd
import os
import pickle
from Scripts.utils import *
from Scripts.FastDTW import *

def _dtw(output, target, window):
    n, m = len(output), len(target)
    w = np.max([window, abs(n - m)])
    dtw_matrix = np.zeros((n + 1, m + 1))
    dtw_matrix += float("Inf")
    dtw_matrix[0, 0] = 0
    for i in range(1, n + 1):
        a, b = np.max([1, i - w]), np.min([m, i + w]) + 1
        dtw_matrix[i, a:b] = 0
        for j in range(a, b):
            cost = np.abs(output[i - 1] - target[j - 1])
            last_min = np.min([dtw_matrix[i - 1, j], dtw_matrix[i, j - 1], dtw_matrix[i - 1, j - 1]])
            dtw_matrix[i, j] = cost + last_min
    return dtw_matrix[-1, -1]

# Hyperparameter grids
params_svr = {
    "kernel": ['rbf', 'linear', 'poly'],
    "C": [0.01, 0.1, 1, 10],
    "gamma": [0.0001, 0.001, 0.01],
    "degree": [1, 2, 3]
}

params_rfg = {
    "n_estimators": [50, 100, 500]
}

params_br = {
    "max_iter": [100, 1000, 2000],
    "tol": [1e-6, 1e-8, 1e-10]
}

params_knn = {
    "n_neighbors": [10, 20, 50, 100],
    "weights": ['uniform', 'distance'],
    "algorithm": ['ball_tree', 'kd_tree', 'brute']
}

params_xgb = {
    "n_estimators": [50, 100, 500],
    "learning_rate": [0.01, 0.1, 0.2],
    "max_depth": [3, 5, 7]
}

params_lgbm = {
    "n_estimators": [50, 100, 500],
    "learning_rate": [0.01, 0.1, 0.2],
    "max_depth": [3, 5, 7]
}

params_cat = {
    "iterations": [500, 1000],
    "learning_rate": [0.01, 0.1, 0.2],
    "depth": [3, 5, 7]
}

params_gbr = {
    "n_estimators": [50, 100, 500],
    "learning_rate": [0.01, 0.1, 0.2],
    "max_depth": [3, 5, 7]
}

params_en = {
    "alpha": [0.1, 1.0, 10.0],
    "l1_ratio": [0.1, 0.5, 0.9]
}

params_lasso = {
    "alpha": [0.01, 0.1, 1.0, 10.0]
}

params_ridge = {
    "alpha": [0.01, 0.1, 1.0, 10.0]
}

params_ada = {
    "n_estimators": [50, 100, 500],
    "learning_rate": [0.01, 0.1, 0.2]
}

# Classifiers
classifiers = {
    "Linear Regression": LinearRegression(),
    "Bayesian Ridge Regression": GridSearchCV(BayesianRidge(), params_br, scoring='neg_mean_squared_error'),
    "Support Vector Regression": GridSearchCV(SVR(), params_svr, scoring='neg_mean_squared_error'),
    "Random Forest Regression": GridSearchCV(RandomForestRegressor(), params_rfg, scoring='neg_mean_squared_error'),
    "KNN-Regression": GridSearchCV(KNeighborsRegressor(), params_knn, scoring='neg_mean_squared_error'),
    "XGBoost Regression": GridSearchCV(XGBRegressor(), params_xgb, scoring='neg_mean_squared_error'),
    "LightGBM Regression": GridSearchCV(LGBMRegressor(), params_lgbm, scoring='neg_mean_squared_error'),
    "CatBoost Regression": GridSearchCV(CatBoostRegressor(silent=True), params_cat, scoring='neg_mean_squared_error'),
    "Gradient Boosting Regression": GridSearchCV(GradientBoostingRegressor(), params_gbr, scoring='neg_mean_squared_error'),
    "ElasticNet Regression": GridSearchCV(ElasticNet(), params_en, scoring='neg_mean_squared_error'),
    "Lasso Regression": GridSearchCV(Lasso(), params_lasso, scoring='neg_mean_squared_error'),
    "Ridge Regression": GridSearchCV(Ridge(), params_ridge, scoring='neg_mean_squared_error'),
    "AdaBoost Regression": GridSearchCV(AdaBoostRegressor(), params_ada, scoring='neg_mean_squared_error')
}

columns = ['Date', 'Open', 'High', 'Low', 'Close', 'Volume', 'Yield', 'PercentageVolume',
           'SMA6', 'EMA6', 'WMA6', 'HMA6', 'SMA20', 'EMA20', 'WMA20', 'HMA20', 'SMA50', 'EMA50', 'WMA50', 'HMA50',
           'SMA100', 'EMA100', 'WMA100', 'HMA100', 'MACD', 'CCI', 'Stochastic Oscillator', 'RSI', 'ROC', 'PPO',
           'KST', 'BOLU', 'BOLD', 'BOLM']

for pair in os.listdir('DataReady'):
    if pair in ['EURUSD']:
        print(pair)
        data = pd.read_csv('DataReady/{}/{}_M15.csv'.format(pair, pair), names=columns, header=0)
        toRemove = ['Volume', 'Date', 'High', 'Low', 'Open', 'Close']
        df = selectData(data, toRemove)
        closingPrices = data['Close']
        closingPrices = closingPrices.reset_index(drop=True)
        normDf = normalizeData(df)
        images = generateImages(normDf)
        images = np.array(images)

        train_X, _, train_Y, _ = train_test_split(images, closingPrices[28:], test_size=0.2, shuffle=True,
                                                  random_state=42)
        _, test_X, _, test_Y = train_test_split(images, closingPrices[28:], test_size=0.2, shuffle=False)
        train_X, test_X = train_X.reshape(train_X.shape[0], 28 * 28).astype(np.float32), test_X.reshape(test_X.shape[0],
                                                                                                        28 * 28).astype(
            np.float32)

        for clf_name, clf in classifiers.items():
            print(f"Training {clf_name}")
            if isinstance(clf, GridSearchCV):
                clf.fit(train_X, train_Y)
            else:
                if hasattr(clf, 'n_estimators'):
                    # For models that support n_estimators, show progress
                    n_estimators = clf.get_params()['n_estimators']
                    with tqdm(total=n_estimators) as pbar:
                        for i in range(n_estimators):
                            clf.set_params(n_estimators=i+1)
                            clf.fit(train_X, train_Y)
                            pbar.update(1)
                else:
                    # For models that don't support iterative fitting
                    clf.fit(train_X, train_Y)

            test_hat_Y = clf.predict(test_X)
            best_param = 0
            try:
                best_param = clf.best_params_
                print(best_param)
            except:
                print(0)

            mse = np.mean((test_hat_Y - test_Y) ** 2)
            corr = np.corrcoef(test_hat_Y, test_Y)[0, 1]
            dti = _dtw(np.array(test_hat_Y), np.array(test_Y), 1)
            fast_dti = fastdtw(test_hat_Y, test_Y, 1)[0]
            print(fast_dti)

            with open("Results/ResultsML.txt", "a+") as f:
                f.write("{}_M15,{},{},{},{},{},{}\n".format(pair, clf_name, mse, corr, dti, fast_dti, best_param))

# Additional model training and saving
with open("Models/ML/MLModels.json", "r") as f:
    models = json.load(f)
for pair in os.listdir('DataReady'):
    if len(pair) == 6 and pair not in ['EURUSD']:
        print(pair)
        data = pd.read_csv('DataReady/{}/{}_M15.csv'.format(pair, pair), names=columns, header=0)
        toRemove = ['Volume', 'Date', 'High', 'Low', 'Open', 'Close']
        df = selectData(data, toRemove)
        closingPrices = data['Close']
        closingPrices = closingPrices.reset_index(drop=True)
        normDf = normalizeData(df)
        images = generateImages(normDf)
        images = np.array(images)

        train_X, _, train_Y, _ = train_test_split(images, closingPrices[28:], test_size=0.2, shuffle=True,
                                                  random_state=42)
        train_X = train_X.reshape(train_X.shape[0], 28 * 28).astype(np.float32)

        for clf_name, clf in classifiers.items():
            print(f"Training {clf_name}")
            if isinstance(clf, GridSearchCV):
                model = clf.set_params(**models[clf_name][pair])
                model.fit(train_X, train_Y)
            else:
                if hasattr(clf, 'n_estimators'):
                    # For models that support n_estimators, show progress
                    n_estimators = clf.get_params()['n_estimators']
                    with tqdm(total=n_estimators) as pbar:
                        for i in range(n_estimators):
                            clf.set_params(n_estimators=i+1)
                            clf.fit(train_X, train_Y)
                            pbar.update(1)
                else:
                    # For models that don't support iterative fitting
                    clf.fit(train_X, train_Y)

                # save the model to disk
                filename = 'Models_cmd/{}_{}.sav'.format(clf_name.replace(" ", ""), pair)
                pickle.dump(clf, open(filename, 'wb'))
                # loaded_model = pickle.load(open(filename, 'rb'))

# Placeholder for progress bar demonstration
a = 3
